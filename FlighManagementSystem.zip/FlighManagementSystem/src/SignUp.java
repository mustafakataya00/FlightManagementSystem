
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class SignUp extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField usertextField;
	private JTextField phoneTextField;
	private JPasswordField passwortextField_1;
	private JButton buttonSubmit; 
	private String userText ;
	private String pwdText ;
	private String phoneText ;
	JButton backbutt;


	public SignUp() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 858, 404);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Delta Airlines");
		lblNewLabel_2.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setBackground(Color.ORANGE);
		lblNewLabel_2.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel_2.setBounds(56, 35, 318, 65);
		contentPane.add(lblNewLabel_2);
		
		backbutt = new JButton("<Back");
		backbutt.setBounds(15,20, 70, 20);
		backbutt.addActionListener(this);
		contentPane.add(backbutt);
		
		JLabel lblNewLabel = new JLabel("UserName");
		lblNewLabel.setForeground((Color.BLACK));
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 13));
		lblNewLabel.setToolTipText("");
		lblNewLabel.setBounds(50, 132, 77, 30);
		contentPane.add(lblNewLabel);
		
		usertextField = new JTextField();
		usertextField.setBounds(137, 139, 176, 20);
		contentPane.add(usertextField);
		usertextField.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground((Color.BLACK));
		lblPassword.setFont(new Font("Verdana", Font.BOLD, 13));
		lblPassword.setBounds(50, 173, 77, 30);
		contentPane.add(lblPassword);
		
		passwortextField_1 = new JPasswordField();
		passwortextField_1.setColumns(10);
		passwortextField_1.setBounds(137, 180, 176, 20);
		contentPane.add(passwortextField_1);
		
		JLabel lblPhone = new JLabel("Phone Number");
		lblPhone.setForeground((Color.BLACK));
		lblPhone.setFont(new Font("Verdana", Font.BOLD, 13));
		lblPhone.setToolTipText("");
		lblPhone.setBounds(50, 210, 150, 30);
		contentPane.add(lblPhone);
		
		phoneTextField = new JTextField();
		phoneTextField.setBounds(170, 217, 176, 20);
		contentPane.add(phoneTextField);
		phoneTextField.setColumns(10);
		
		buttonSubmit = new JButton("Register");
		buttonSubmit.setBounds(160,260, 100, 20);
		buttonSubmit.addActionListener(this);
		contentPane.add(buttonSubmit);
		
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("AirlinePic.jpg"));
		lblNewLabel_1.setBounds(0, 0, 858, 404);
		contentPane.add(lblNewLabel_1);
	
		 setVisible(true);
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
	
		if(e.getSource()==buttonSubmit)
		{
			
			userText = usertextField.getText();
			pwdText = passwortextField_1.getText();
			phoneText = phoneTextField.getText();
			
			 	Connection conn = BddComm.Connect();
	            java.sql.Statement stmt = null;
	            
				try {
					stmt = conn.createStatement();
				} catch (SQLException e1) {
				
					e1.printStackTrace();
				}
				try {
					
					PreparedStatement ps = conn.prepareStatement("Insert into users(username,password,phone_num) values(? , ? , ?)");
					ps.setString(1,userText);
					ps.setString(2,pwdText);
					ps.setString(3, phoneText);
					int row = ps.executeUpdate();
					if(row != 1)
					{
						JOptionPane.showMessageDialog(this, "Failed SignUp ");
					}
					else
					{
						this.dispose();
						JOptionPane.showMessageDialog(this, "SignUp Successful");
						Login loginuser = new Login();
					}
					}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
		}
		else if(e.getSource() == backbutt)
		{
			this.dispose();
			Login loginuser = new Login();
		}
	}
		
		
	}
