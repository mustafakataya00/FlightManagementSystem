import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Login extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField usertextField;
	private JPasswordField passwortextField_1;
	private JButton buttonSubmit; 
	private String userText ;
	private String pwdText ;
	private JButton signupbutt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 100, 858, 404);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Delta Airlines");
		lblNewLabel_2.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setBackground(Color.ORANGE);
		lblNewLabel_2.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel_2.setBounds(56, 35, 318, 65);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel = new JLabel("UserName");
		lblNewLabel.setForeground((Color.BLACK));
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 13));
		lblNewLabel.setToolTipText("");
		lblNewLabel.setBounds(50, 132, 77, 30);
		contentPane.add(lblNewLabel);
		
		usertextField = new JTextField();
		usertextField.setBounds(137, 139, 176, 20);
		contentPane.add(usertextField);
		usertextField.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground((Color.BLACK));
		lblPassword.setFont(new Font("Verdana", Font.BOLD, 13));
		lblPassword.setBounds(50, 173, 77, 30);
		contentPane.add(lblPassword);
		
		passwortextField_1 = new JPasswordField();
		passwortextField_1.setColumns(10);
		passwortextField_1.setBounds(137, 180, 176, 20);
		contentPane.add(passwortextField_1);
		
		buttonSubmit = new JButton("Submit");
		buttonSubmit.setBounds(150,220, 100, 20);
		buttonSubmit.addActionListener(this);
		contentPane.add(buttonSubmit);
		
		JLabel text = new JLabel();
		text.setForeground((Color.BLACK));
		text.setFont(new Font("Verdana", Font.BOLD, 13));
		text.setBounds(100, 250, 370, 30);
		text.setText("<html>Don't have an account ?</html>");
		signupbutt = new JButton("Sign Up");
		signupbutt.setBounds(280, 256, 90, 20);
		signupbutt.addActionListener(this);
		contentPane.add(text);
		text.setCursor(new Cursor(Cursor.HAND_CURSOR));
		contentPane.add(text);
		contentPane.add(signupbutt);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("AirlinePic.jpg"));
		lblNewLabel_1.setBounds(0, 0, 858, 404);
		contentPane.add(lblNewLabel_1);
		
		 setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == buttonSubmit)
		{
			boolean check = false ;
		    
					 userText = usertextField.getText();
					 pwdText = passwortextField_1.getText();;
			           
			            
			           Connection conn = BddComm.Connect();
			            java.sql.Statement stmt = null;
			            
						try {
							stmt = conn.createStatement();
						} catch (SQLException e1) {
						
							e1.printStackTrace();
						}
						
				        try {
				        	
						ResultSet rs=stmt.executeQuery("select * from users ;"); 
						while(rs.next())
						{
							
							if(rs.getString("username").equals(getUserText()) && rs.getString("password").equals(getPwdText()))
							{
								 check = true;
								
								 break; 
							}
						}
						if(check)
						{
							 JOptionPane.showMessageDialog(this, "Login Successful");
							 this.dispose();
							 AdminPage ad = new AdminPage();
						}
						else
						{
							JOptionPane.showMessageDialog(this, "Invalid Username or Password");
						}
						
			          
						} catch (SQLException e1) {
							
							e1.printStackTrace();
						} 
				       
			        }
		if(e.getSource() == signupbutt)
					{
						this.dispose();
						SignUp signuser = new SignUp();
					}
		}
	

	public String getUserText() {
		return userText;
	}

	public String getPwdText() {
		return pwdText;
	}
		
	
}

