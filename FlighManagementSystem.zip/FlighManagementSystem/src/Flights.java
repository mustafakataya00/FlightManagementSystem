import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import net.proteanit.sql.DbUtils;

public class Flights extends JFrame implements ActionListener,MouseListener{

	private JPanel contentPane;
	private JTextField codetextField;
	private JTextField nbOfseatstextField;
	private JButton saveButt ;
	private JButton editButt ;
	private JButton deleteButt ;
	private JButton BackButt ;
	JTable jt;
	int key=0;
	JComboBox sourceBox;
	JComboBox destBox;
	JDateChooser calendar;

	
	public Flights() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 955, 487);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Delta Airlines");
		lblNewLabel.setBounds(385, 11, 171, 24);
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 19));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Manage Flights");
		lblNewLabel_2.setBounds(389, 36, 153, 18);
		lblNewLabel_2.setFont(new Font("Verdana", Font.BOLD, 14));
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Flight Code");
		lblNewLabel_1.setForeground(new Color(237,70,14));
		lblNewLabel_1.setFont(new Font("Tahoma",  Font.BOLD, 15));
		lblNewLabel_1.setBounds(21, 75, 111, 30);
		contentPane.add(lblNewLabel_1);
		
		codetextField = new JTextField();
		codetextField.setColumns(10);
		codetextField.setBounds(10, 105, 142, 20);
		contentPane.add(codetextField);
		
		JLabel src = new JLabel("Source");
		src.setForeground(new Color(237,70,14));
		src.setFont(new Font("Tahoma",  Font.BOLD, 15));
		src.setBounds(196, 75, 111, 30);
		contentPane.add(src);
		
		JLabel datetakeoff = new JLabel("TakeOff Date");
		datetakeoff.setForeground(new Color(237,70,14));
		datetakeoff.setFont(new Font("Tahoma",  Font.BOLD, 15));
		datetakeoff.setBounds(553, 75, 111, 30);
		contentPane.add(datetakeoff);
		
		JLabel nseat = new JLabel("Number Of Seats");
		nseat.setForeground(new Color(237,70,14));
		nseat.setFont(new Font("Tahoma",  Font.BOLD, 15));
		nseat.setBounds(700, 75, 153, 30);
		contentPane.add(nseat);
		
		JLabel dest = new JLabel("Destination");
		dest.setForeground(new Color(237,70,14));
		dest.setFont(new Font("Tahoma",  Font.BOLD, 15));
		dest.setBounds(359, 75, 111, 30);
		contentPane.add(dest);
		
		sourceBox = new JComboBox();
		sourceBox.setModel(new DefaultComboBoxModel(new String[] {"Paris", "Lebanon", "Germany", "Brazil", "Spain", "America", "Russia"}));
		sourceBox.setFont(new Font("Verdana", Font.PLAIN, 14));
		sourceBox.setBounds(185, 104, 85, 22);
		contentPane.add(sourceBox);
		
		destBox = new JComboBox();
		destBox.setModel(new DefaultComboBoxModel(new String[] {"Paris", "Lebanon", "Germany", "Brazil", "Spain", "America", "Russia"}));
		destBox.setFont(new Font("Verdana", Font.PLAIN, 14));
		destBox.setBounds(357, 104, 85, 22);
		contentPane.add(destBox);
		
		 calendar = new JDateChooser();
		calendar.setBounds(550, 104, 105, 20);
		contentPane.add(calendar);
		
		System.out.print(calendar.getDate());
		
		nbOfseatstextField = new JTextField();
		nbOfseatstextField.setColumns(10);
		nbOfseatstextField.setBounds(700, 104, 120, 20);
		contentPane.add(nbOfseatstextField);
		
		saveButt = new JButton("Save");
		saveButt.setBounds(220, 140, 90, 20);
		saveButt.addActionListener(this);
		contentPane.add(saveButt);
		
		editButt = new JButton("Edit");
		editButt.setBounds(350, 140, 90, 20);
		editButt.addActionListener(this);
		contentPane.add(editButt);
		
		deleteButt = new JButton("Delete");
		deleteButt.setBounds(460, 140, 90, 20);
		deleteButt.addActionListener(this);
		contentPane.add(deleteButt);
		
		BackButt = new JButton("Back");
		BackButt.setBounds(570, 140, 90, 20);
		BackButt.addActionListener(this);
		contentPane.add(BackButt);
		
		JLabel FlightListLabel = new JLabel("Flights List");
		FlightListLabel.setForeground(new Color(237,70,14));
		FlightListLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		FlightListLabel.setBounds(220, 170, 111, 30);
		contentPane.add(FlightListLabel);
		
		String data[][]={ {"101","Amit","670000"},    
                {"102","Jai","780000"},    
                {"101","Sachin","700000"}};
		
		String column[]={"ID","NAME","SALARY"}; 
		
		 jt=new JTable(data,column);    
		jt.setBounds(30,200,850,200); 
		jt.addMouseListener(this);
		
		JScrollPane sp=new JScrollPane(jt);
		sp.setBounds(30,200,850,200); 
		contentPane.add(sp);          
		DisplayFlights();
		
		JLabel pic = new JLabel("");
		pic.setIcon(new ImageIcon("board-flights.jpg"));
		pic.setBounds(0, 0, 955, 487);
		contentPane.add(pic);
		
		
		
		setVisible(true);
	}

	private void DisplayFlights()
	{
		Connection conn = BddComm.Connect();
        java.sql.Statement stmt = null;
        
		try {
			stmt = conn.createStatement();
		} catch (SQLException e1) {
		
			e1.printStackTrace();
		}
        
			try {
				
				ResultSet rs = stmt.executeQuery("Select * from flight");
				jt.setModel(DbUtils.resultSetToTableModel(rs));
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	}
	
	private void Clear()
	{
	    codetextField.setText("");
	    nbOfseatstextField.setText("");
	    sourceBox.setSelectedItem("");
	    destBox.setSelectedItem("");
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		
		if(e.getSource() == BackButt)
		{
			this.dispose();
			AdminPage ap = new AdminPage();
		}
		else if(e.getSource() == saveButt)
		{
			if(codetextField.getText().isEmpty() || nbOfseatstextField.getText().isEmpty()|| sourceBox.getSelectedIndex()==-1 || destBox.getSelectedIndex()==-1 )
			{
				JOptionPane.showMessageDialog(this, "Missing Informations");
			}
			else
			{
				
				Connection conn = BddComm.Connect();
		         
				try {
					
					PreparedStatement ps = conn.prepareStatement("Insert into flight(FlightCode,Source,Destination,date,Seats) values(?,?,?,?,?)");
					ps.setString(1,codetextField.getText());
					ps.setString(2,sourceBox.getSelectedItem().toString());
					ps.setString(3,destBox.getSelectedItem().toString());
					ps.setString(4,calendar.getDate().toString());
					ps.setInt(5,Integer.valueOf(nbOfseatstextField.getText()));
					
					
					int row = ps.executeUpdate();
					if(row != 1)
					{
						JOptionPane.showMessageDialog(this,"Failed to Insert the new Flight! ");
					}
					JOptionPane.showMessageDialog(this, "Flight Added!");
					DisplayFlights();
					Clear();
					}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
				
			
			}
			
		}
		else if(e.getSource() == editButt)
		{

			if(key == 0)
			{
				JOptionPane.showMessageDialog(this, "Please Select A Flight To Edit");
			}
			else
			{
				
				Connection conn = BddComm.Connect();
		         
				try {
					
					String Query = "Update flight set Source=? , Destination=? , date=? ,Seats=? where FlightID=? ";
					PreparedStatement ps = conn.prepareStatement(Query);
					
					
					ps.setString(1,sourceBox.getSelectedItem().toString());
					ps.setString(2,destBox.getSelectedItem().toString());
					ps.setString(3,calendar.getDate().toString());
					ps.setInt(4, Integer.valueOf(nbOfseatstextField.getText()));
					ps.setInt(5,key);
					
					int row = ps.executeUpdate();
					if(row != 1)
					{
						JOptionPane.showMessageDialog(this,"Failed to Update Flight! ");
					}
					JOptionPane.showMessageDialog(this, "Flight Updated!");
					DisplayFlights();
					Clear();
					}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
				
			
			}
			
		}
		else if(e.getSource() == deleteButt)
		{
			if(key == 0)
			{
				JOptionPane.showMessageDialog(this, "Please Select a Flight to Delete");
			}
			else
			{
			Connection conn = BddComm.Connect();
			 java.sql.Statement stmt = null;
		        
				try {
					stmt = conn.createStatement();
				} catch (SQLException e1) {
				
					e1.printStackTrace();
				}
		        
	         
			try {
			
			String deleteStr="DELETE FROM flight where FlightID="+key;
		    stmt.executeUpdate(deleteStr);
		    JOptionPane.showMessageDialog(this, "Flight Deleted");
		    DisplayFlights();
			
		}catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
			
			
		}
		}
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		DefaultTableModel model = (DefaultTableModel) jt.getModel();
		int myIndex = jt.getSelectedRow();
			key = Integer.valueOf(model.getValueAt(myIndex,0).toString());
		    nbOfseatstextField.setText(model.getValueAt(myIndex, 5).toString());
		    sourceBox.setSelectedItem(model.getValueAt(myIndex, 2).toString());
		    destBox.setSelectedItem(model.getValueAt(myIndex, 3).toString());
//		    calendar.setDate(model.getValueAt(myIndex, 2).toString());
		   
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}

