import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

public class TicketBooking extends JFrame implements ActionListener,MouseListener{

	private JPanel contentPane;
	private JTextField nametextField;
	private JTextField AmounttextField;
	private JTextField NationalitytextField;
	private JTextField passportnbtextField;
	private JTextField GendertextField;
	private JTextField SeattextField;
	private JTextField tSeattextField;
	private JButton BookButt ;
	private JButton deleteButt ;
	private JButton BackButt ;
	private JTable jt;
	JComboBox passBox;
	JComboBox flightBox;
	int key =0;
	
	
	public TicketBooking() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1300, 487);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Delta Airlines");
		lblNewLabel.setBounds(585, 11, 171, 24);
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 19));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Ticket Booking");
		lblNewLabel_2.setBounds(592, 36, 153, 18);
		lblNewLabel_2.setFont(new Font("Verdana", Font.BOLD, 14));
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Passenger Name");
		lblNewLabel_1.setForeground(new Color(237,70,14));
		lblNewLabel_1.setFont(new Font("Tahoma",  Font.BOLD, 15));
		lblNewLabel_1.setBounds(156, 75, 141, 30);
		contentPane.add(lblNewLabel_1);
		
		nametextField = new JTextField();
		nametextField.setColumns(10);
		nametextField.setBounds(155, 104, 107, 25);
		contentPane.add(nametextField);
		
		JLabel lblNewLabel_1_1 = new JLabel("Passenger Id");
		lblNewLabel_1_1.setForeground(new Color(237,70,14));
		lblNewLabel_1_1.setFont(new Font("Tahoma",  Font.BOLD, 15));
		lblNewLabel_1_1.setBounds(21, 77, 141, 30);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Passport Number");
		lblNewLabel_1_1_1.setForeground(new Color(237,70,14));
		lblNewLabel_1_1_1.setFont(new Font("Tahoma",  Font.BOLD, 15));
		lblNewLabel_1_1_1.setBounds(543, 75, 141, 30);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel AddressLabel = new JLabel("Amount");
		AddressLabel.setForeground(new Color(237,70,14));
		AddressLabel.setFont(new Font("Tahoma",  Font.BOLD, 15));
		AddressLabel.setBounds(690, 75, 153, 30);
		contentPane.add(AddressLabel);
		
		JLabel TotalSeatLabel = new JLabel("Total Seats");
		TotalSeatLabel.setForeground(new Color(237,70,14));
		TotalSeatLabel.setFont(new Font("Tahoma",  Font.BOLD, 15));
		TotalSeatLabel.setBounds(830, 75, 153, 30);
		contentPane.add(TotalSeatLabel);
		
		tSeattextField = new JTextField();
		tSeattextField.setColumns(10);
		tSeattextField.setBounds(830, 104, 95, 20);
		contentPane.add(tSeattextField);
		
		JLabel SeatLabel = new JLabel("Seat");
		SeatLabel.setForeground(new Color(237,70,14));
		SeatLabel.setFont(new Font("Tahoma",  Font.BOLD, 15));
		SeatLabel.setBounds(960, 75, 153, 30);
		contentPane.add(SeatLabel);
		
		SeattextField = new JTextField();
		SeattextField.setColumns(10);
		SeattextField.setBounds(960, 104, 95, 20);
		contentPane.add(SeattextField);
		
		JLabel PhoneLabel = new JLabel("Nationality");
		PhoneLabel.setForeground(new Color(237,70,14));
		PhoneLabel.setFont(new Font("Tahoma",  Font.BOLD, 15));
		PhoneLabel.setBounds(1100, 75, 153, 30);
		contentPane.add(PhoneLabel);
		
		JLabel lblNewLabel_1_1_3 = new JLabel("Flight Code");
		lblNewLabel_1_1_3.setForeground(new Color(237,70,14));
		lblNewLabel_1_1_3.setFont(new Font("Tahoma",  Font.BOLD, 15));
		lblNewLabel_1_1_3.setBounds(309, 75, 111, 30);
		contentPane.add(lblNewLabel_1_1_3);
		
		passBox = new JComboBox();
		passBox.setModel(new DefaultComboBoxModel(new String[] {""}));
		passBox.setFont(new Font("Verdana", Font.PLAIN, 14));
		passBox.setBounds(10, 105, 100, 20);
		passBox.addActionListener(this);
		contentPane.add(passBox);
		
		flightBox = new JComboBox();
		flightBox.setModel(new DefaultComboBoxModel(new String[] {""}));
		flightBox.setFont(new Font("Verdana", Font.PLAIN, 14));
		flightBox.setBounds(309, 104, 97, 25);
		flightBox.addActionListener(this);
		contentPane.add(flightBox);
		
		JLabel GenderLabel = new JLabel("Gender");
		GenderLabel.setForeground(new Color(237,70,14));
		GenderLabel.setFont(new Font("Tahoma",  Font.BOLD, 15));
		GenderLabel.setBounds(430, 75, 153, 30);
		contentPane.add(GenderLabel);
		
		GendertextField = new JTextField();
		GendertextField.setColumns(10);
		GendertextField.setBounds(430, 104, 95, 20);
		contentPane.add(GendertextField);
		
		passportnbtextField = new JTextField();
		passportnbtextField.setColumns(10);
		passportnbtextField.setBounds(540, 104, 125, 20);
		contentPane.add(passportnbtextField);
		
		AmounttextField = new JTextField();
		AmounttextField.setColumns(10);
		AmounttextField.setBounds(690, 104, 120, 20);
		contentPane.add(AmounttextField);
		
		NationalitytextField = new JTextField();
		NationalitytextField.setColumns(10);
		NationalitytextField.setBounds(1100, 104, 120, 20);
		contentPane.add(NationalitytextField);
		
		
		BookButt = new JButton("Book");
		BookButt.setBounds(350, 140, 90, 20);
		BookButt.addActionListener(this);
		contentPane.add(BookButt);
		
		deleteButt = new JButton("Reset");
		deleteButt.setBounds(460, 140, 90, 20);
		deleteButt.addActionListener(this);
		contentPane.add(deleteButt);
		
		BackButt = new JButton("Back");
		BackButt.setBounds(570, 140, 90, 20);
		BackButt.addActionListener(this);
		contentPane.add(BackButt);
		
		
		
		JLabel FlightListLabel = new JLabel("Bookings");
		FlightListLabel.setForeground(new Color(237,70,14));
		FlightListLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		FlightListLabel.setBounds(450, 170, 131, 30);
		contentPane.add(FlightListLabel);
		
		
		String data[][]={};
		
		String column[]={}; 
		
		jt=new JTable(data,column);    
		jt.setBounds(30,200,1200,200); 
		jt.addMouseListener(this);
		jt.setEnabled(false);
		
		JScrollPane sp=new JScrollPane(jt);
		sp.setBounds(30,200,1200,200); 
		contentPane.add(sp);          
		
				JLabel pic = new JLabel("");
		pic.setIcon(new ImageIcon("Tickets.jpg"));
		pic.setBounds(0, 0, 1400, 487);
		contentPane.add(pic);

		GetPassengers();
		GetFlights();
	
		DisplayTickets();
		
		nametextField.setEditable(false);
		GendertextField.setEditable(false);
		passportnbtextField.setEditable(false);
	    NationalitytextField.setEditable(false);
	    tSeattextField.setEditable(false);
		
		
		setVisible(true);
	}
	
	private void GetPassengers()
	{
		
		Connection conn = BddComm.Connect();
        java.sql.Statement stmt = null;
        
		try {
			stmt = conn.createStatement();
		} catch (SQLException e1) {
		
			e1.printStackTrace();
		}
        
			try {
				
				ResultSet rs = stmt.executeQuery("Select * from passengers");
				while(rs.next())
				{
					String PID = String.valueOf(rs.getInt("PassengerID"));
					passBox.addItem(PID);
					
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	}
	
	private void GetPassengersData()
	{
		
		Connection conn = BddComm.Connect();
        java.sql.Statement stmt = null;
        
		try {
			stmt = conn.createStatement();
		} catch (SQLException e1) {
		
			e1.printStackTrace();
		}
        
			try {
				
				ResultSet rs = stmt.executeQuery("Select * from passengers where PassengerID =" + (String) passBox.getSelectedItem());
				while(rs.next())
				{
					
					nametextField.setText(rs.getString("Name"));
					GendertextField.setText(rs.getString("Gender"));
					 passportnbtextField.setText(rs.getString("Passport"));
					 NationalitytextField.setText(rs.getString("Nationality"));
					
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	}
	private void GetFlightsData()
	{
		
		Connection conn = BddComm.Connect();
        java.sql.Statement stmt = null;
        
		try {
			stmt = conn.createStatement();
		} catch (SQLException e1) {
		
			e1.printStackTrace();
		}
        
			try {
				
				ResultSet rs = stmt.executeQuery("Select * from flight where FlightCode ='" +  (String)flightBox.getSelectedItem() +"'" );
				while(rs.next())
				{
					tSeattextField.setText(rs.getString("Seats"));
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	}
	
	
	
	private void GetFlights()
	{
		
		Connection conn = BddComm.Connect();
        java.sql.Statement stmt = null;
        
		try {
			stmt = conn.createStatement();
		} catch (SQLException e1) {
		
			e1.printStackTrace();
		}
        
			try {
				
				ResultSet rs1 = stmt.executeQuery("Select * from flight");
				while(rs1.next())
				{
					String FID =rs1.getString("FlightCode");
					flightBox.addItem(FID);
					
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	}
	
	private void DisplayTickets()
	{
		Connection conn = BddComm.Connect();
        java.sql.Statement stmt = null;
        
		try {
			stmt = conn.createStatement();
		} catch (SQLException e1) {
		
			e1.printStackTrace();
		}
        
			try {
				
				ResultSet rs = stmt.executeQuery("Select * from booking");
				jt.setModel(DbUtils.resultSetToTableModel(rs));
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	}
	private void Clear()
	{
		passBox.setSelectedIndex(-1);
		flightBox.setSelectedIndex(-1);
		nametextField.setText("");
		GendertextField.setText("");
		 passportnbtextField.setText("");
		 NationalitytextField.setText("");
		 AmounttextField.setText("");
		 tSeattextField.setText("");
		 SeattextField.setText("");
	}

	
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == BackButt)
		{
			this.dispose();
			AdminPage admin = new AdminPage();
		}
		else if(e.getSource() == BookButt)
		{
			if(passBox.getSelectedIndex()==-1 || flightBox.getSelectedIndex()==-1 || AmounttextField.getText().isEmpty() )
			{
				JOptionPane.showMessageDialog(this, "Missing Informations");
			}
			else
			{
				
				Connection conn = BddComm.Connect();
		         
				try {
					
					PreparedStatement ps = conn.prepareStatement("Insert into booking(Name,FlightCode,Gender,Passport,Amount,Nationality,seat) values(?,?,?,?,?,?,?)");
					ps.setString(1,nametextField.getText());
					ps.setString(2,flightBox.getSelectedItem().toString());
					ps.setString(3,GendertextField.getText());
					ps.setString(4,passportnbtextField.getText());
					ps.setString(5,AmounttextField.getText());
					ps.setString(6,NationalitytextField.getText());
					ps.setInt(7, Integer.valueOf(SeattextField.getText()));
					
					int row = ps.executeUpdate();
					if(row != 1)
					{
						JOptionPane.showMessageDialog(this,"Failed to Book the Ticket! ");
					}
					JOptionPane.showMessageDialog(this, "Ticket Booked!");
					DisplayTickets();
					Clear();
					
					}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
				
			
			}
			
			
		
			
			
		}
		else if(e.getSource() == deleteButt)
		{
			passBox.setSelectedIndex(-1);
			flightBox.setSelectedIndex(-1);
			nametextField.setText("");
			GendertextField.setText("");
			 passportnbtextField.setText("");
			 NationalitytextField.setText("");
			 AmounttextField.setText("");
			 tSeattextField.setText("");
			 SeattextField.setText("");
			
		}
		else if(e.getSource() == passBox)
		{
			GetPassengersData();
			
		}
		else if(e.getSource() == flightBox)
		{
			GetFlightsData();
		}
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}

