import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;

import net.proteanit.sql.DbUtils;

public class Cancellation extends JFrame implements ActionListener,MouseListener{

	private JPanel contentPane;
	private JTextField codetextField;
	private JButton CancelButt ;
	private JButton deleteButt ;
	private JButton BackButt ;
	JComboBox ticketbox;
	JTable jt;
	JDateChooser calendar;

	
	public Cancellation() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 955, 487);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Delta Airlines");
		lblNewLabel.setForeground(new Color(237,70,14));
		lblNewLabel.setBounds(385, 11, 171, 24);
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 19));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Ticket Cancellation");
		lblNewLabel_2.setForeground(new Color(237,70,14));
		lblNewLabel_2.setBounds(389, 36, 153, 18);
		lblNewLabel_2.setFont(new Font("Verdana", Font.BOLD, 14));
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Flight Code");
		lblNewLabel_1.setForeground(new Color(237,70,14));
		lblNewLabel_1.setFont(new Font("Tahoma",  Font.BOLD, 15));
		lblNewLabel_1.setBounds(420, 75, 111, 30);
		contentPane.add(lblNewLabel_1);
		
		codetextField = new JTextField();
		codetextField.setColumns(10);
		codetextField.setBounds(420, 104, 85, 22);
		codetextField.setEditable(false);
		contentPane.add(codetextField);
		
		
		JLabel lblNewLabel_1_1 = new JLabel("Ticket ID");
		lblNewLabel_1_1.setForeground(new Color(237,70,14));
		lblNewLabel_1_1.setFont(new Font("Tahoma",  Font.BOLD, 15));
		lblNewLabel_1_1.setBounds(200, 75, 111, 30);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Cancellation Date");
		lblNewLabel_1_1_1.setForeground(new Color(237,70,14));
		lblNewLabel_1_1_1.setFont(new Font("Tahoma",  Font.BOLD, 15));
		lblNewLabel_1_1_1.setBounds(600, 75, 111, 30);
		contentPane.add(lblNewLabel_1_1_1);
		
		
	
		
		ticketbox = new JComboBox();
		ticketbox.setModel(new DefaultComboBoxModel(new String[] {""}));
		ticketbox.setFont(new Font("Verdana", Font.PLAIN, 14));
		ticketbox.setBounds(200, 105, 100, 20);
		ticketbox.addActionListener(this);
		contentPane.add(ticketbox);
		
		
		 calendar = new JDateChooser();
		calendar.setBounds(600, 104, 105, 20);
		contentPane.add(calendar);
		
		
		CancelButt = new JButton("Cancel");
		CancelButt.setBounds(310, 140, 90, 20);
		CancelButt.addActionListener(this);
		contentPane.add(CancelButt);
		
		deleteButt = new JButton("Reset");
		deleteButt.setBounds(415, 140, 90, 20);
		deleteButt.addActionListener(this);
		contentPane.add(deleteButt);
		
		BackButt = new JButton("Back");
		BackButt.setBounds(520, 140, 90, 20);
		BackButt.addActionListener(this);
		contentPane.add(BackButt);
		
		JLabel FlightListLabel = new JLabel("Bookings");
		FlightListLabel.setForeground(new Color(237,70,14));
		FlightListLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		FlightListLabel.setBounds(400, 170, 111, 30);
		contentPane.add(FlightListLabel);
		
		String data[][]={};
		
		String column[]={}; 
		
		 jt=new JTable(data,column);    
		jt.setBounds(30,200,850,200); 
		jt.addMouseListener(this);
		
		JScrollPane sp=new JScrollPane(jt);
		sp.setBounds(30,200,850,200); 
		contentPane.add(sp);          
		
		JLabel pic = new JLabel("");
		pic.setIcon(new ImageIcon("cancel.jpg"));
		pic.setBounds(0, 0, 955, 487);
		contentPane.add(pic);
		
		GetTicketId();
		DisplayCancelledTickets();
		
		
		setVisible(true);
	}
	
	private void GetTicketId()
	{
		
			
			Connection conn = BddComm.Connect();
	        java.sql.Statement stmt = null;
	        
			try {
				stmt = conn.createStatement();
			} catch (SQLException e1) {
			
				e1.printStackTrace();
			}
	        
				try {
					
					ResultSet rs = stmt.executeQuery("Select * from booking");
					while(rs.next())
					{
						String TID = String.valueOf(rs.getInt("TicketID"));
						ticketbox.addItem(TID);
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
		
	}
	
	private void DisplayCancelledTickets()
	{
		Connection conn = BddComm.Connect();
        java.sql.Statement stmt = null;
        
		try {
			stmt = conn.createStatement();
		} catch (SQLException e1) {
		
			e1.printStackTrace();
		}
        
			try {
				
				ResultSet rs = stmt.executeQuery("Select * from cancellation");
				jt.setModel(DbUtils.resultSetToTableModel(rs));
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	}
	private void GetTicketsData()
	{
		
		Connection conn = BddComm.Connect();
        java.sql.Statement stmt = null;
        
		try {
			stmt = conn.createStatement();
		} catch (SQLException e1) {
		
			e1.printStackTrace();
		}
        
			try {
				
				ResultSet rs = stmt.executeQuery("Select * from booking where TicketID = " + (String) ticketbox.getSelectedItem());
				while(rs.next())
				{
					
					codetextField.setText(rs.getString("FlightCode"));
					
					
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	}
	
	private void Cancel()
	{
		Connection conn = BddComm.Connect();
		 java.sql.Statement stmt = null;
	        
			try {
				stmt = conn.createStatement();
			} catch (SQLException e1) {
			
				e1.printStackTrace();
			}
	        
         
		try {
		
		String deleteStr="DELETE FROM booking where TicketID=" +ticketbox.getSelectedItem().toString();
	    stmt.executeUpdate(deleteStr);
	 
		
	}catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} 
		
	}
		
		
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == ticketbox)
		{
			GetTicketsData();
		}
		else if(e.getSource() == BackButt)
		{
			this.dispose();
			AdminPage ap = new AdminPage();
		}
		else if(e.getSource()==CancelButt)
		{
			if(ticketbox.getSelectedIndex()==-1 || codetextField.getText().isEmpty() )
			{
				JOptionPane.showMessageDialog(this, "Missing Informations");
			}
			else
			{
				
				Connection conn = BddComm.Connect();
		         
				try {
					
					PreparedStatement ps = conn.prepareStatement("Insert into cancellation(TicketID,FlightCode,CancellationDate) values(?,?,?)");
					
					ps.setInt(1, Integer.valueOf(ticketbox.getSelectedItem().toString()));
					ps.setString(2,codetextField.getText());
					ps.setString(3,calendar.getDate().toString());
					
					int row = ps.executeUpdate();
					if(row != 1)
					{
						JOptionPane.showMessageDialog(this,"Failed to Cancel the Ticket! ");
					}
					JOptionPane.showMessageDialog(this, "Ticket Cancelled!");
					
					Cancel();
					DisplayCancelledTickets();
					
					}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			
	}
			
		}
		else if(e.getSource()==deleteButt)
		{
			ticketbox.setSelectedIndex(-1);
			codetextField.setText("");
		}
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}

