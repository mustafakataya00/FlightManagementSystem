import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

public class Passengers extends JFrame implements ActionListener,MouseListener{

	private JPanel contentPane;
	private JTextField nametextField;
	private JTextField AddresstextField;
	private JTextField PhonetextField;
	private JTextField passportnbtextField;
	private JButton saveButt ;
	private JButton editButt ;
	private JButton deleteButt ;
	private JButton BackButt ;
	JComboBox natio;
	JComboBox gende;
	String pname;
	String pnat;
	String padd;
	String ppass;
	String pphne;
	String pgen;
	JTable jt;
	int key = 0;
	

	
	public Passengers() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 487);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Delta Airlines");
		lblNewLabel.setBounds(385, 11, 171, 24);
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 19));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Manage Passengers");
		lblNewLabel_2.setBounds(389, 36, 153, 18);
		lblNewLabel_2.setFont(new Font("Verdana", Font.BOLD, 14));
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Passenger Name");
		lblNewLabel_1.setForeground(new Color(237,70,14));
		lblNewLabel_1.setFont(new Font("Tahoma",  Font.BOLD, 15));
		lblNewLabel_1.setBounds(21, 77, 141, 30);
		contentPane.add(lblNewLabel_1);
		
		nametextField = new JTextField();
		nametextField.setColumns(10);
		nametextField.setBounds(10, 105, 142, 20);
		contentPane.add(nametextField);
		
		JLabel nat= new JLabel("Nationality");
		nat.setForeground(new Color(237,70,14));
		nat.setFont(new Font("Tahoma",  Font.BOLD, 15));
		nat.setBounds(196, 75, 111, 30);
		contentPane.add(nat);
		
		JLabel pnum = new JLabel("Passport Number");
		pnum.setForeground(new Color(237,70,14));
		pnum.setFont(new Font("Tahoma",  Font.BOLD, 15));
		pnum.setBounds(513, 75, 141, 30);
		contentPane.add(pnum);
		
		JLabel AddressLabel = new JLabel("Address");
		AddressLabel.setForeground(new Color(237,70,14));
		AddressLabel.setFont(new Font("Tahoma",  Font.BOLD, 15));
		AddressLabel.setBounds(690, 75, 153, 30);
		contentPane.add(AddressLabel);
		
		JLabel PhoneLabel = new JLabel("Phone");
		PhoneLabel.setForeground(new Color(237,70,14));
		PhoneLabel.setFont(new Font("Tahoma",  Font.BOLD, 15));
		PhoneLabel.setBounds(850, 75, 153, 30);
		contentPane.add(PhoneLabel);
		
		JLabel gen = new JLabel("Gender");
		gen.setForeground(new Color(237,70,14));
		gen.setFont(new Font("Tahoma",  Font.BOLD, 15));
		gen.setBounds(359, 75, 111, 30);
		contentPane.add(gen);
		
		natio = new JComboBox();
		natio.setModel(new DefaultComboBoxModel(new String[] {"Afghanian","Albanian","Algerian","American","Andorran","Angolan","Anguillan","Argentinian","Armenian","Australian","Austrian",
				"Azerbaijani","Bahraini","Brazilian","British","Bangladeshi","Canadian","Czech","	Cameroonian","Danish","Egyptian","Emirati","French","German","Greek","Indian","	Iranian","Italian","Iraqi","Japanese","Jordanian","Kuwaiti","Lebanese","Libyan","Mexican","	Moroccan","Norwegian","Omani","Palestinian","Portuguese","Paraguayan","Pakistani","	Puerto Rican","Qatari","Romanian","Russian","Saudi Arabian","Spanish","Swedish","Swiss","Sri Lankan","Senegalese","Syrian","Ukrainian","Yemeni"}));
		natio.setFont(new Font("Verdana", Font.PLAIN, 14));
		natio.setBounds(185, 104, 97, 25);
		contentPane.add(natio);
		
		gende = new JComboBox();
		gende.setModel(new DefaultComboBoxModel(new String[] {"Male","Female"}));
		gende.setFont(new Font("Verdana", Font.PLAIN, 14));
		gende.setBounds(357, 104, 97, 25);
		contentPane.add(gende);
		
		passportnbtextField = new JTextField();
		passportnbtextField.setColumns(10);
		passportnbtextField.setBounds(510, 104, 125, 20);
		contentPane.add(passportnbtextField);
		
		AddresstextField = new JTextField();
		AddresstextField.setColumns(10);
		AddresstextField.setBounds(690, 104, 120, 20);
		contentPane.add(AddresstextField);
		
		PhonetextField = new JTextField();
		PhonetextField.setColumns(10);
		PhonetextField.setBounds(850, 104, 120, 20);
		contentPane.add(PhonetextField);
		
		saveButt = new JButton("Save");
		saveButt.setBounds(220, 140, 90, 20);
		saveButt.addActionListener(this);
		contentPane.add(saveButt);
		
		editButt = new JButton("Edit");
		editButt.setBounds(350, 140, 90, 20);
		editButt.addActionListener(this);
		contentPane.add(editButt);
		
		deleteButt = new JButton("Delete");
		deleteButt.setBounds(460, 140, 90, 20);
		deleteButt.addActionListener(this);
		contentPane.add(deleteButt);
		
		BackButt = new JButton("Back");
		BackButt.setBounds(570, 140, 90, 20);
		BackButt.addActionListener(this);
		contentPane.add(BackButt);
		
		JLabel FlightListLabel = new JLabel("Passengers List");
		FlightListLabel.setForeground(new Color(237,70,14));
		FlightListLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		FlightListLabel.setBounds(400, 170, 131, 30);
		contentPane.add(FlightListLabel);
		
		
		String data[][]={};
		
		String column[]={}; 
		
		 jt=new JTable(data,column);    
		jt.setBounds(30,200,900,200); 
		jt.addMouseListener(this);
		
		
		JScrollPane sp=new JScrollPane(jt);
		sp.setBounds(30,200,900,200); 
		contentPane.add(sp);          
		
		JLabel pic = new JLabel("");
		pic.setIcon(new ImageIcon("Passengers.jpg"));
		pic.setBounds(0, 0, 2050, 487);
		contentPane.add(pic);
		
		DisplayPassengers();
		
		
		setVisible(true);
	}
	
	private void DisplayPassengers()
	{
		Connection conn = BddComm.Connect();
        java.sql.Statement stmt = null;
        
		try {
			stmt = conn.createStatement();
		} catch (SQLException e1) {
		
			e1.printStackTrace();
		}
        
			try {
				
				ResultSet rs = stmt.executeQuery("Select * from passengers");
				jt.setModel(DbUtils.resultSetToTableModel(rs));
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	}
	private void Clear()
	{
	    nametextField.setText("");
	    passportnbtextField.setText("");
	    AddresstextField.setText("");
	    PhonetextField.setText("");
}

	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		pname = nametextField.getText();
		padd = AddresstextField.getText();
		pphne = PhonetextField.getText();
		ppass = passportnbtextField.getText();
		pnat = (String) natio.getSelectedItem();
		pgen = (String) gende.getSelectedItem();
		
		
		if(e.getSource() == BackButt)
		{
			this.dispose();
			AdminPage admin = new AdminPage();
		}
		else if(e.getSource() == saveButt)
		{
			if(pname.isEmpty() || padd.isEmpty() || ppass.isEmpty() || pphne.isEmpty() || pnat.isEmpty() || pgen.isEmpty())
			{
				JOptionPane.showMessageDialog(this, "Missing Informations");
			}
			else
			{
				
				Connection conn = BddComm.Connect();
		         
				try {
					
					PreparedStatement ps = conn.prepareStatement("Insert into passengers(Name,Nationality,Gender,Passport,Address,Phone) values(?,?,?,?,?,?)");
					ps.setString(1,pname);
					ps.setString(2,pnat);
					ps.setString(3,pgen);
					ps.setString(4,ppass);
					ps.setString(5,padd);
					ps.setString(6,pphne);
					
					int row = ps.executeUpdate();
					if(row != 1)
					{
						JOptionPane.showMessageDialog(this,"Failed to Insert the new client! ");
					}
					JOptionPane.showMessageDialog(this, "Passenger Added!");
					DisplayPassengers();
					Clear();
					}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
				
			
			}
			

		}
		else if(e.getSource() == editButt)
		{
			if(key == 0)
			{
				JOptionPane.showMessageDialog(this, "Please Select A passenger To Edit");
			}
			else
			{
				
				Connection conn = BddComm.Connect();
		         
				try {
					
					String Query = "Update passengers set Name=?,Nationality=?,Passport=?,Address=?,Phone=? where PassengerID=?";
					PreparedStatement ps = conn.prepareStatement(Query);
					ps.setString(1,pname);
					ps.setString(2,pnat);
					ps.setString(3,ppass);
					ps.setString(4,padd);
					ps.setString(5,pphne);
					ps.setInt(6,key);
					
					int row = ps.executeUpdate();
					if(row != 1)
					{
						JOptionPane.showMessageDialog(this,"Failed to Update Passenger! ");
					}
					JOptionPane.showMessageDialog(this, "Passenger Updated!");
					DisplayPassengers();
					Clear();
					}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
				
			
			}
			
		}
		else if(e.getSource() ==deleteButt)
		{
			if(key == 0)
			{
				JOptionPane.showMessageDialog(this, "Please Select a passenger to Delete");
			}
			else
			{
			Connection conn = BddComm.Connect();
			 java.sql.Statement stmt = null;
		        
				try {
					stmt = conn.createStatement();
				} catch (SQLException e1) {
				
					e1.printStackTrace();
				}
		        
	         
			try {
			
			String deleteStr="DELETE FROM passengers where passengerID="+key;
		    stmt.executeUpdate(deleteStr);
		    JOptionPane.showMessageDialog(this, "Passenger Deleted");
		    DisplayPassengers();
			
		}catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
			
		}
		}

	}
	
	

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		DefaultTableModel model = (DefaultTableModel) jt.getModel();
		int myIndex = jt.getSelectedRow();
			key = Integer.valueOf(model.getValueAt(myIndex,0).toString());
			nametextField.setText(model.getValueAt(myIndex, 1).toString());
		    passportnbtextField.setText(model.getValueAt(myIndex, 4).toString());
		    AddresstextField.setText(model.getValueAt(myIndex, 5).toString());
		    PhonetextField.setText(model.getValueAt(myIndex, 6).toString());
		    natio.setSelectedItem(model.getValueAt(myIndex, 2).toString());
		    gende.setSelectedItem(model.getValueAt(myIndex, 3).toString());
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	
	
}

