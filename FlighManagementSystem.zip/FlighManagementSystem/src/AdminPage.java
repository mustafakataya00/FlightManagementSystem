import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class AdminPage extends JFrame implements ActionListener{

	private JPanel contentPane;
	JButton Passengers;
	JButton btnAddTickets;
	JButton btnFlights;
	JButton btnCancellation;
	JButton backbutt;
	

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public AdminPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1046, 438);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Passengers = new JButton("Modify Passenger");
		Passengers.setForeground(Color.BLACK);
		Passengers.setBounds(90, 200, 160, 36);
		Passengers.addActionListener(this);
		contentPane.add(Passengers);
		
		 btnAddTickets = new JButton("Add Tickets");
		btnAddTickets.setBounds(340, 200, 141, 36);
		btnAddTickets.addActionListener(this);
		contentPane.add(btnAddTickets);
		
		 btnFlights = new JButton("Flights");
		btnFlights.setBounds(564, 200, 141, 36);
		btnFlights.addActionListener(this);
		contentPane.add(btnFlights);
		
		 btnCancellation = new JButton("Cancellation");
		btnCancellation.setBounds(796, 200, 151, 36);
		btnCancellation.addActionListener(this);
		contentPane.add(btnCancellation);
		
		JLabel lbl1 = new JLabel("Delta Airlines");
		lbl1.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 30));
		lbl1.setBackground(new Color(240, 240, 240));
		lbl1.setForeground(Color.BLACK);
		lbl1.setBounds(188, 44, 293, 118);
		contentPane.add(lbl1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("Admin.jpg"));
		lblNewLabel.setBounds(0, 0, 1030, 399);
		contentPane.add(lblNewLabel);
		
		backbutt = new JButton("<LOGOUT");
		backbutt.setBounds(15,20, 90, 20);
		backbutt.addActionListener(this);
		contentPane.add(backbutt);
		
		setVisible(true);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == Passengers)
		{
			this.dispose();
			Passengers psg = new Passengers();
		}
		else if(e.getSource() == btnFlights)
		{
			this.dispose();
			Flights psg = new Flights();
		}
		else if(e.getSource() == btnAddTickets)
		{
			this.dispose();
			TicketBooking psg = new TicketBooking();
		}
		else if(e.getSource() == btnCancellation)
		{
			this.dispose();
			Cancellation psg = new Cancellation();
		}
		else if(e.getSource() == backbutt)
		{
			this.dispose();
			Login loginuser = new Login();
		}
	
	}
}
