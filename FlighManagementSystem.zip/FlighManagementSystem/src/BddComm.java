import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BddComm {
private BddComm() {};
	
	public static Connection con = null;
	
	public static Connection Connect()
	{
		
		try{  
	        Class.forName("com.mysql.jdbc.Driver");  
	        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flightsystem","root","");  
		
	}catch(Exception e){ System.out.println(e + " ERROR IN CONNECTION TO DATABASE SERVER ");}
		
		return con; 
	}


	public static void Disconnect() throws SQLException
	{
		con.close();
	}




}
